import { DarkThemeToggle, Navbar, TextInput } from "flowbite-react";
import { IoSearchSharp } from "react-icons/io5";
import { useDispatch, useSelector } from "react-redux";
import { Link } from "react-router-dom";
import { userActions } from "../../../Store/UserSlice";
import { TRootState } from "../../../Store/store";
import { searchActions } from "../../../Store/SearchSlice";
import { GrDomain } from "react-icons/gr";

// type HeaderProps = {
//   isLoggedIn: boolean;
//   setIsloggedIN: (isLoggedIn: boolean) => void;
// };

const Header = () => {
  const dispatch = useDispatch();
  const user = useSelector((state: TRootState) => state.userSlice.user);

  return (
    <Navbar fluid rounded className="bg-slate-800">
      <Navbar.Brand as={Link} to="/home">
        <span className="self-center whitespace-nowrap text-xl font-semibold text-white">
          <GrDomain />

          Data Project
        </span>

      </Navbar.Brand>

      <Navbar.Brand  >

      </Navbar.Brand>

      <Navbar.Toggle />
      <Navbar.Collapse>
        <TextInput
          placeholder="Search"
          rightIcon={IoSearchSharp}
          className=""
          onChange={(e) =>
            dispatch(searchActions.setSearchWord(e.target.value))
          }
        />
        <Navbar.Link as={Link} to={"/"} href="/" className="text-white">
          Home
        </Navbar.Link>

        {user === null && (
          <Navbar.Link
            as={Link}
            to={"/signin"}
            href="/signin"
            className="text-white"
          >
            Sign In
          </Navbar.Link>
        )}

        {user === null && (
          <Navbar.Link
            as={Link}
            to={"/signup"}
            href="/signup"
            className="text-white"
          >
            Sign Up
          </Navbar.Link>
        )}

        {user !== null && (
          <Navbar.Link
            className="cursor-pointer text-white"
            onClick={() => dispatch(userActions.logout())}
          >
            Sign Out
          </Navbar.Link>
        )}
        {user && (
          <Navbar.Link
            as={Link}
            to={"/profile"}
            href="/profile"
            className="text-white"
          >
            Profile
          </Navbar.Link>
        )}

        {user && (
          <Navbar.Link
            as={Link}
            to={"/favourites"}
            href="/favourites"
            className="text-white"
          >
            Favourites
          </Navbar.Link>
        )}

        {user && user.isBusiness && (
          <Navbar.Link
            as={Link}
            to={"/create-card"}
            href="/create-card"
            className="text-white"
          >
            Create Card
          </Navbar.Link>
        )}


        {user && user.isBusiness && (
          <Navbar.Link
            as={Link}
            to={"/MyCards"}
            href="/MyCards"
            className="text-white"
          >
            My Cards
          </Navbar.Link>
        )}

        <><DarkThemeToggle /></>
      </Navbar.Collapse>
    </Navbar>
  );
};
export default Header;